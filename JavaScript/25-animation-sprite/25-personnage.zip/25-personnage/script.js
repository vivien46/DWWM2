let perso = document.querySelector('#perso');

// Init
perso.style.left = 0;
perso.style.top = 0;

document.addEventListener('keyup',function(){
    perso.classList.remove('anime');
});

document.addEventListener('keydown', function (e) {
    console.log(e);
    console.log('vous avez tapé sur ' + e.key);
    let posLeftActuelle;
    let posTopActuelle;
    switch (e.key) {

        case 'ArrowRight':
        case 'd':
        case 'D':
            perso.style.backgroundPositionY = '0px';
            perso.classList.add('anime');
            posLeftActuelle = parseInt(perso.style.left);
            posLeftActuelle += 5;
            perso.style.left = posLeftActuelle + 'px';
            break;
        case 'ArrowLeft':
        case 'q':
        case 'Q':
            perso.style.backgroundPositionY = '-50px';
            perso.classList.add('anime');
            posLeftActuelle = parseInt(perso.style.left);
            if (posLeftActuelle > 0) {
                posLeftActuelle -= 5;
                perso.style.left = posLeftActuelle + 'px';
            }
            break;
        case 'ArrowUp':
        case 'z':
        case 'Z':
            perso.style.backgroundPositionY = '-100px';
            perso.classList.add('anime');
            posTopActuelle = parseInt(perso.style.top); // 160px => 160
            if (posTopActuelle > 0) {
                posTopActuelle -= 5;
                perso.style.top = posTopActuelle + 'px';
            }
            break;

        case 'ArrowDown':
        case 's':
        case 'S':
            perso.style.backgroundPositionY = '-150px';
            perso.classList.add('anime');
            posTopActuelle = parseInt(perso.style.top);
            posTopActuelle += 5;
            perso.style.top = posTopActuelle + 'px';
            break;
    }
}
);