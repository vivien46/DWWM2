<template>
     <h1>Bienvenue sur le VueJS de Vivien</h1>
     <p>Tu t'appel {{ user.firstName }}</p>
     <p>Tu as {{ age }} ans</p>
     <p>Est tu majeur ? {{ majority }}</p>
     <input :type="typeInput">
     <button @click="$event => direMerci()">Cliquez Ici</button>
     <button @click="mounted()">Cliquez Ici</button>
    <hr>

    <h2>Exercice 1</h2>

    <input type="text" @input="changeColor($event.target.value)"/>
    <div class="carre" :style="{ backgroundColor: colorSquare}"></div>

    <hr>
    <h2>Exercice 2</h2>
<!-- 
    <button @click="showHello = !showHello">
      <span v-if="showHello == true">disparition</span>
      <span v-else>Apparition</span>
      du Hello</button><br>
    <p v-if="showHello">Hello</p> -->
    <button @click="appararition = !appararition">
    <span v-if="appararition"> Disparition</span>
    <span v-else>Apparition </span>
  </button>
  <p v-if="appararition" :style="{backgroundColor: 'red', color: 'white'}">Hello ! </p>

    <hr>
    <h2>Exercice 3</h2>
    <ul>
    <li v-for="user in users" :key="user">{{ user.firstName }} {{ user.lastName }}</li>
  </ul>
</template>

<script>
export default {
  name: 'HelloWorld',
  data(){
    return {
      user: {firstName: 'gégé'}, 
      age:  37,
      majority : true,
      typeInput : 'number',
      colorSquare: 'grey',
      //exercice 2
    appararition: false,

    //exercice3
    users: [ 
        {
          firstName: "Julie",
          lastName: "Mai",
        },
        {
          firstName: "Julie",
          lastName: "Mai",
        },
        {
          firstName: "Julie",
          lastName: "Mai",
        },
        {
          firstName: "Julie",
          lastName: "Mai",
        },
        {
          firstName: "Julie",
          lastName: "Mai",
        },
        
      ]
    }
  },

  methods: {
    direMerci() {
      console.log('Merci à toi !');
    }, 
    
    //exercice1
    changeColor(color){
      this.colorSquare = color;
    }, 
  }
}
    
   

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1{
  color: blue;
  text-align: center;
}

.carre{
  height: 100px;
  width: 100px;
}
</style>
