$(function(){

    /*
        jQuery permet de faire de l'ajax via 3 méthodes
            $.get()  
            $.post()

                - url
                - params (json)
                - function(){}
                - format(xml,text,json)


            $.ajax()            
    */

    $.ajax({
        url : 'countries-FR.json',
        method : 'GET', // GET ou POST
        data : {},
        dataType : 'json',
        success : function(datas){
            console.log(datas);
            Object.values(datas).forEach(function(pays){
                $('#contenu').append(pays + '<br>');
            });
        }, // sur réussite
        error : function(error){}, // sur échec
        complete : function(){
            console.log("C'est fini");
        }, // systématique que ce soit réussite ou échec
        beforeSend : function(){
            console.log("ça commence");
        } // avant l'envoi de la requete ajax
    });

    // Avec $.get()

    $.get('countries-FR.json',{},function(datas){        
        console.log(datas) ;
        Object.values(datas).forEach(function(pays){
            $('#pays').append(`<option>${pays}</option>`);
        });
    },'json');

    // ou
    let url = 'countries-FR.json';
    $.ajax(url)
        .done(function(datas){}) // success
        .fail(function(){}) // error
        .always(function(){}); // complete

    $.ajax(url,{
        method : 'POST'
    });



});