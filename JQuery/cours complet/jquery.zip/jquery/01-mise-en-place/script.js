// Version Javascript vanilla
//document.addEventListener('DOMContentLoaded',function(){
// tout le code JS
// });


// Versions jQuery

// jQuery(function(){
// code js
// });

$(function () {

    // code js

});
