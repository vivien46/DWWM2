<template>
    <main class="container container-1-1">
        <div>
            <div class="card">
            </div>
            <div class="card">
            </div>
        </div>
    </main>
</template>

<script>
    export default {
        name: 'HomePageView'
    }
</script>