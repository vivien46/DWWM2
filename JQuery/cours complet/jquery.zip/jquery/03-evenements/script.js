// DOM ready
$(function () {

    // la méthode on() permet d'écouter un événement
    $('#carrebleu').on('click', function () {

        $(this)
            .removeClass('bleu')
            .addClass('rouge');

        /*
            classList.add()       addClass()
            classList.remove()    removeClass()
            classlist.contains()  hasClass()
            classList.toggle()    toggleClass()          

        */

    });

    $('#carrebleu')
        .on('mouseenter', function () {
            $(this)
                .removeClass('carre')
                .addClass('rond');
        })
        .on('mouseleave', function () {
            $(this)
                .removeClass('rond')
                .addClass('carre');
        });

    /*
        jQuery possède les méthodes
            .show(500)
            .hide(500)
            .toggle(500)
                    chiffre en ms
                    'slow','fast'

    */

    // quand je clique sur le rond jaune, je cache le rond vert, si je reclique sur le rond jaune, je fais réapparaitre le rond vert
    $('#rondjaune').on('click', function () {
        $('#rondvert').toggle(600);
    });

    // Animations d'apparition/disparition
    /*
        .slideDown()
        .slideUp()
        .slideToggle()

        Fondus
        .fadeIn()
        .fadeOut()
        .fadeToggle()      
        .fadeTo()
    */

    /*
    Si je clique sur l'image, je la fais disparaitre en fondu sortant, je change l'url de l'image que je fais apparaitre en fondu entrant
    */

    let i = 1;
    $('#monimage').on('click', function () {

        // beaucoup de fonctions de jQuery permettent d'ajouter une callback permettant d'enchainer sur du code une fois l'animation terminée
        // .fadeOut(500,callback)

        $(this).fadeOut(500, function () {
            i++;
            $(this)
                .attr('src', `https://picsum.photos/200/200?random=${i}`)
                .fadeIn(800);
        });


    });

    // Fondu (estompage) jusqu'à un niveau d'opacité précis
    $('#carrebleu').fadeTo(500,.4); // atteint l'opacité .4 en 500 ms







}); // fin du DOM ready
