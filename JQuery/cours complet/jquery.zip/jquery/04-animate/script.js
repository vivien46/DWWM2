$(function () {

    $('#rondvert').on('click', function () {

        $(this).animate({
            'width': '150px',
            'height': '150px',
            'top': '+=50px', // on peut modifier une valeur de manière relative à sa position actuelle
            'left': '+=100px'
        }, 600, function () {
            // fonction de callback optionnelle
            console.log('animation terminée');
        });

    });

    /*
    Exercice:
    quand on clique sur le carré bleu on aimerait qu'il effectue les animations suivantes :
     - se décaler vers la droite 
     - descendre
     - se décaler vers la gauche
     - remonter à sa position initiale
 
     /!\ si on raccorde plusieurs méthodes animate() à un élément, elles s'exécutent l'une après l'autre
    */

    // version 1
    // $('#carrebleu').on('click', function () {

    //     $(this)
    //         .animate({ left: '200px' }, 600)
    //         .animate({ top: '80px' }, 600)
    //         .animate({ left: 0 }, 600)
    //         .animate({ top: 0 }, 600);
    // });

    // version 2
    $('#carrebleu').on('click', function () {
        $(this)
            .animate({ left: '200px' }, 600, function () {
                $(this)
                    .animate({ top: '80px' }, 600, function () {
                        $(this)
                            .animate({ left: 0 }, 600, function () {
                                $(this)
                                    .animate({ top: 0 }, 600);
                            });
                    });
            });
    });



    // Filtre et fenetre
    /*
        Au bout de 2secondes, on fait apparaitre le filtre en fondu et on deploie la fenetre

        sur clic de la fenetre, on enroule la fenetre et on fait disparaitre le filtre en fondu

    */

    
    setTimeout(function(){

        $('#filtre').fadeIn(600,function(){
            $('#fenetre').slideDown(600);
        });  


    },2000);

    $('#fenetre').on('click',function(){

        $(this).slideUp(600,function(){
            $('#filtre').fadeOut(600);
        });

    });


    // Confirmer le suivi d'un lien
    $('a').on('click',function(e){

        // return(confirm('Etes vous sur de vouloir aller sur youtube ?'));

        e.preventDefault();
        let reponse = confirm('Etes vous sur de vouloir aller sur youtube ?');
        if(reponse){
            // window.location.href = this.getAttribute('href');
            window.open( this.getAttribute('href'), '_blank');
        }

    });


    /*
        .parent() qui permet de selectionner le parent de l'élement
        .find('span') qui permet de trouver un enfant
        .closest('span')
        .before()
        .after()
        .append('') ajoute à l'intérieur de l'élément à la suite

        // Getters/Setters

        .html()  getter (innerHTML)
        .html('<h2>titre</h2>') setter

        .text() getter (innerText)
        .text('du texte') setter

        .attr('type')  getter   (équivalent de getAttribute('type'))
        .attr('type','text') setter (équivalent de setAttribute('type','text'))

        .prop('disabled') getter
        .prop('disabled', false) setter


    */
    

  


});