$(function () {

    $('.before,.after').each(function () {

        console.log($(this));
        $(this).css('background-image', `url(${$(this).attr('data-img')})`);
    });

    $('.before').css({
        'width': '50%',
        'z-index': 2
    });

    $('.after').css({
        'width': '100%',
        'z-index': 1
    })

    $('.beforeafter').append('<div class="barre"><div class="curseur"></div></div>');


    $('.barre').draggable({
        containment : 'parent',
        axis : 'x',
        drag : function(){
            let position = $(this).css('left');
            console.log(position);
            $('.before').css('width',position);
        }
    });




});