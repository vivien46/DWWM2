<template>
  <NavbarComponent />
  <HomePageView />  
</template>

<script>
import NavbarComponent from './components/NavbarComponent.vue'
import HomePageView from './views/HomePageView.vue'

export default {
  name: 'App',
  components: {
    NavbarComponent,
    HomePageView
  }
}
</script>

<style>
html, body, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
b, u, i, center,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, embed,
figure, figcaption, footer, header, hgroup,
menu, nav, output, ruby, section, summary,
time, mark, audio, video {
  margin: 0;
  padding: 0;
  border: 0;
  font-size: 100%;
  font-weight: inherit;
  vertical-align: baseline;
}

/* HTML5 display-role reset for older browsers */
article, aside, details, figcaption, figure,
footer, header, hgroup, menu, nav, section {
  display: block;
}

body {
  line-height: 1;
}

ol, ul {
  list-style: none;
}

blockquote, q {
  quotes: none;
}

blockquote:before, blockquote:after,
q:before, q:after {
  content: "";
  content: none;
}

table {
  border-collapse: collapse;
  border-spacing: 0;
}

*, *::before, *::after {
  box-sizing: border-box;
}

body {
  margin: 0;
}

html {
  scroll-behavior: smooth;
  background-color: #000;
}

hr {
  border: 0.5px solid #fff;
}

a {
  cursor: pointer;
}

.pointer {
  cursor: pointer;
}

.bg-dark {
  background-color: #000 !important;
}

.bg-secondary {
  background-color: #5E95B7 !important;
}

.bg-primary {
  background-color: #FFFFFF !important;
}

html {
  font-size: 16px;
}

body {
  font-family: "Roboto", sans-serif;
  line-height: 1.5;
  color: #efefef;
}

a {
  color: inherit;
  text-decoration: none;
  transition: 0.3s;
}

.text-center {
  text-align: center;
}

.text-right {
  text-align: right !important;
}

.title {
  margin: 5px 0 15px 0;
  text-transform: uppercase;
  font-size: 1.3rem;
  font-weight: 800;
}

.subtitle {
  margin: 5px 0 10px 0;
  text-transform: uppercase;
  font-size: 1.1rem;
  font-weight: 500;
}

.text-light {
  color: #efefef;
}

.text-primary {
  color: #FFFFFF !important;
}

.text-warning {
  color: #C08B59 !important;
}

.text-danger {
  color: #FF7070;
}

.text-secondary {
  color: #4FDAC6;
}

.bold {
  font-weight: 500;
}

.link {
  text-decoration: underline;
  color: #5E95B7;
  font-style: italic;
}

.info {
  font-weight: #000;
  font-style: italic;
  font-size: 0.9rem;
}

.container {
  padding: 0 25px;
  display: -ms-grid;
  display: grid;
  -ms-grid-columns: 1fr;
  grid-template-columns: 1fr;
  grid-gap: 25px;
}

@media only screen and (min-width: 960px) {
  .container {
    margin-left: 106px;
    padding: 0 41px;
    grid-gap: 41px;
  }

  .container-1-1 {
    -ms-grid-columns: 1fr 1fr;
    grid-template-columns: 1fr 1fr;
  }

  .container-1-2 {
    -ms-grid-columns: 1fr 1.75fr;
    grid-template-columns: 1fr 1.75fr;
  }

  .container-2-1 {
    -ms-grid-columns: 1.75fr 1fr;
    grid-template-columns: 1.75fr 1fr;
  }

  .d-grid-2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-gap: 10px;
  }
}
.mt-5 {
  margin-top: 35px !important;
}

.mb-5 {
  margin-bottom: 35px !important;
}

.ml-5 {
  margin-left: 35px !important;
}

.mr-5 {
  margin-right: 35px !important;
}

.mt-4 {
  margin-top: 25px !important;
}

.mb-4 {
  margin-bottom: 25px !important;
}

.ml-4 {
  margin-left: 25px !important;
}

.mr-4 {
  margin-right: 25px !important;
}

.mt-3 {
  margin-top: 15px !important;
}

.mb-3 {
  margin-bottom: 15px !important;
}

.ml-3 {
  margin-left: 15px !important;
}

.mr-3 {
  margin-right: 15px !important;
}

.mt-2 {
  margin-top: 10px !important;
}

.mb-2 {
  margin-bottom: 10px !important;
}

.ml-2 {
  margin-left: 10px !important;
}

.mr-2 {
  margin-right: 10px !important;
}

.mb-0 {
  margin-bottom: 0 !important;
}

.pr-5 {
  padding-right: 25px !important;
}

.mt-50 {
  margin-top: 50px !important;
}

.ml-100 {
  margin-left: 100px !important;
}

.d-flex {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.d-flex-left {
  display: flex;
  justify-content: left;
  align-items: center;
}

.w100 {
  width: 100% !important;
}

@media only screen and (min-width: 540px) {
  .float-right {
    float: right !important;
  }

  .float-left {
    float: left !important;
  }

  .d-flex.right {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: end;
    -ms-flex-pack: end;
    justify-content: flex-end;
  }

  .d-flex-buttons {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .d-flex-right-buttons {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
}
.display-none-mobile {
  display: none;
}

@media only screen and (min-width: 540px) {
  .display-none-mobile {
    display: block;
  }
}
@media only screen and (min-width: 960px) {
  .display-none-desktop {
    display: none;
  }
}
button {
  font-size: 1rem;
  line-height: 1.5rem;
}

.btn {
  display: inline-block;
  margin: 5px 0;
  padding: 10px 0;
  width: 100%;
  text-transform: uppercase;
  text-align: center;
  color: #fff;
  background-color: #000;
  border: solid 2px #fff;
  -webkit-transition: 0.3s;
  -o-transition: 0.3s;
  transition: 0.3s;
  cursor: pointer;
}

.btn:hover {
  background-color: #fff;
  color: #000;
}

@media only screen and (min-width: 540px) {
  .btn {
    width: auto;
    padding: 10px 20px;
    margin: 5px;
  }
}
.form-group {
  width: 100%;
  margin: 15px 0;
}

.form-group label {
  display: block;
  margin-bottom: 10px;
  padding-left: 7px;
}

.form-group .form-control {
  width: 100%;
  padding: 10px;
  color: #fff;
  border-color: #fff;
  background-color: #000;
  -webkit-box-shadow: none;
  box-shadow: none;
}

.form-group-2-1 {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
}

.form-group-2-1 .icon {
  margin-left: 21px;
}

.form-group.checkbox {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
}

.select {
  width: 100%;
  padding: 5px 10px;
  margin: 5px 0;
  text-align: center;
  color: #fff;
  border: solid 2px #fff;
  background-color: #000;
  cursor: pointer;
  -webkit-appearance: none;
  -moz-appearance: none;
  background-image: linear-gradient(45deg, transparent 50%, #FFF 50%), linear-gradient(135deg, #FFF 50%, transparent 50%);
  background-position: calc(100% - 16px) calc(1em + -2px), calc(100% - 11px) calc(1em + -2px), calc(100% - 2.5em) 0.5em;
  background-size: 5px 5px, 5px 5px, 1px 1.5em;
  background-repeat: no-repeat;
}

@media only screen and (min-width: 540px) {
  .select {
    width: auto;
    margin: 5px 0;
  }

  .form-group-1-1 {
    display: -ms-grid;
    display: grid;
    -ms-grid-columns: 1fr 21px 1fr;
    grid-template-columns: 1fr 1fr;
    grid-gap: 21px;
  }

  .form-group-1-1-1 {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    grid-gap: 10px;
  }
}
.form-group-search {
  position: relative;
}

.form-group-search .icon {
  position: absolute;
  top: 10px;
  right: 15px;
}

.contain-alert {
  margin-top: 25px;
  padding: 0 25px;
}

@media only screen and (min-width: 960px) {
  .contain-alert {
    margin-top: 41px;
    margin-left: 106px;
    padding: 0 41px;
  }
}
.alert {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  margin: 41px 0 0 0;
  padding: 5px 20px;
  color: #000;
  font-weight: 500;
  border-width: 2px;
  border-style: solid;
}

.alert-danger {
  background-color: #C75757;
}

.alert-warning {
  background-color: #C08B59;
}

.alert-info {
  background-color: #5E95B7;
}

.alert-success {
  background-color: #68AB6F;
}

.alert .icon {
  cursor: pointer;
  -webkit-transition: 0.3s;
  -o-transition: 0.3s;
  transition: 0.3s;
}

.alert .icon:hover {
  color: #efefef;
}

.badge {
  width: 100%;
  display: inline-block;
  margin: 10px 0;
  padding: 2px 18px;
  text-align: center;
  color: #fff;
  border: solid 2px #fff;
}

.badge-secondary {
  border-color: #5E95B7;
  color: #5E95B7;
}

.badge-warning {
  border-color: #C08B59;
  color: #C08B59;
}

.badge-danger {
  border-color: #C75757;
  color: #C75757;
}

@media only screen and (min-width: 540px) {
  .badge {
    width: auto;
    margin: 2px 0;
  }
}
.card {
  margin: 25px 0;
  padding: 21px;
  height: auto;
  border: solid 2px #fff;
  background-color: #000;
}

.card.tall {
  max-height: 650px;
}

.card.little {
  max-height: 350px;
}

.card.medium {
  max-height: 450px;
}

.nested-card {
  margin: 30px 0;
  border: 1px solid #FFFFFF;
}

.nested-card .card-header {
  display: flex;
  justify-content: center;
  text-align: center;
  height: 35px;
  color: #000;
  background-color: #FFFFFF;
}

.nested-card .card-body {
  padding: 25px;
}

@media only screen and (min-width: 960px) {
  .card {
    margin: 41px 0;
  }

  .card.sticky {
    top: 107px;
    position: sticky;
    height: 80vh;
  }

  .card.flex {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }

  .card.flex .table {
    height: 100%;
  }
}
.navbar-height {
  height: 66px;
}

.navbar {
  padding: 10px 30px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 66px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  text-transform: uppercase;
  color: #fff;
  background-color: #000;
  border: solid 2px #fff;
  z-index: 5;
}

.navbar .nav {
  display: none;
}

.navbar .personal-nav,
.navbar .personal-nav .profil {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
}

.navbar .personal-nav .profil,
.navbar .personal-nav span {
  cursor: pointer;
  -webkit-transition: 0.3s;
  -o-transition: 0.3s;
  transition: 0.3s;
}

.navbar .personal-nav span:hover {
  color: #fff;
}

.navbar .personal-nav .profil {
  margin-left: 10px;
  padding: 10px 0;
}

.navbar img {
  height: 45px;
  border-radius: 5px;
}

.navbar .icon {
  margin: 0 10px;
}

.navbar .icon-bell {
  position: relative;
}

.navbar .count {
  position: absolute;
  left: 20px;
  top: 8px;
  font-size: 0.8rem;
  font-weight: 800;
  color: #fff;
}

.contain-burger {
  height: 35px;
  cursor: pointer;
}

.burger::before {
  content: "";
  display: inline-block;
  position: absolute;
  top: 15px;
  height: 4px;
  width: 40px;
  border-radius: 5px;
  background-color: #efefef;
}

.burger {
  position: relative;
  height: 4px;
  width: 40px;
  border-radius: 5px;
  background-color: #efefef;
}

.burger::after {
  content: "";
  display: inline-block;
  position: absolute;
  top: 30px;
  height: 4px;
  width: 40px;
  border-radius: 5px;
  background-color: #efefef;
}

.navbar-dropdown {
  position: relative;
}

.navbar-dropdown-content {
  display: none;
  position: absolute;
  padding: 12px 16px;
  min-width: 160px;
  color: #efefef;
  background-color: #efefef;
  border-radius: 5px;
  -webkit-box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
}

.navbar-dropdown:hover .navbar-dropdown-content {
  display: block;
}

.dropdown-left {
  right: 0px;
}

.dropdown-middle {
  left: -50px;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown-link {
  display: block;
}

.dropdown-link:hover {
  color: #FFFFFF;
}

.vertical-navbar {
  display: none;
  position: fixed;
  top: 66px;
  left: 0;
  bottom: 0;
  width: 106px;
  padding: 24px 0;
  text-transform: uppercase;
  text-align: center;
  font-weight: 500;
  background-color: #000;
  border: solid 2px #fff;
  z-index: 2;
}

.nav-vertical-link {
  padding: 10px 0;
  margin-bottom: 10px;
  width: 100%;
  display: inline-block;
}

.nav-vertical-link:hover {
  background-color: #5E95B7;
}

.nav-vertical-link.active {
  background-color: #5E95B7;
}

.nav-vertical-link p {
  margin-top: 6px;
}

@media only screen and (min-width: 960px) {
  .contain-burger {
    display: none;
  }

  .navbar,
.navbar .nav {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
  }

  .navbar .nav .navbar-link {
    padding: 21px 0;
    margin: 0 17.5px;
    font-weight: 500;
  }

  .navbar .nav a:hover {
    color: #5E95B7;
  }

  .navbar-link.active {
    color: #5E95B7;
  }

  .vertical-navbar {
    display: block;
  }
}
.information .img {
  height: 50px;
  width: 50px;
  margin-right: 15px;
  border-radius: 5px;
}

.information .img.big {
  height: 130px;
  width: 130px;
}

.small-information {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-pack: justify;
  -ms-flex-pack: justify;
  justify-content: space-between;
}

@media only screen and (min-width: 540px) {
  .information {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
  }

  .medium-information {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
  }
}
.information-comment .img {
  height: 50px;
  width: 50px;
  margin-right: 15px;
  border-radius: 5px;
}

.information-comment {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}

.table {
  display: block;
  width: 100%;
  overflow-y: scroll;
  height: 250px;
}

.table table {
  width: 100%;
}

.table thead {
  font-weight: 500;
  color: #efefef;
  background-color: #5E95B7;
}

.table th {
  padding: 5px 10px;
}

.table td {
  padding: 15px 10px;
}

.table thead th:nth-child(1),
.table tbody td:nth-child(1) {
  text-align: left;
}

.table thead th:nth-child(2),
.table tbody td:nth-child(2) {
  text-align: right;
}

.table tr {
  border-bottom: 1px solid #FFFFFF;
}

.table tbody tr:hover {
  background-color: #5E95B7;
  -webkit-transition: 0.3s;
  -o-transition: 0.3s;
  transition: 0.3s;
  cursor: pointer;
}

.table tr.active {
  background-color: #5E95B7;
}

.notifications tbody tr {
  border-top: 1px solid #5c636a;
  border-bottom: 1px solid #5c636a;
}

.notifications tbody tr.active {
  background: #343434;
  font-weight: bold;
  color: #efefef;
}

.notifications tbody tr {
  background-color: #444444;
  color: #cdcdcd;
}

.notifications tbody tr:hover {
  background-color: #444444;
  border-bottom-color: #3a86ff !important;
}

@media only screen and (min-width: 960px) {
  .table {
    height: auto;
  }
}
.tabs {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  color: #efefef;
  text-transform: uppercase;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
}

.tab {
  word-break: break-word;
  cursor: pointer;
  padding: 10px 5px;
  display: inline-block;
  border-radius: 3px 3px 0px 0px;
}

.panels .panel {
  min-height: 600px;
}

.panel {
  display: none;
  -webkit-animation: fadein 0.8s;
  animation: fadein 0.8s;
}

@-webkit-keyframes fadein {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes fadein {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
.radio {
  display: none;
}

#one:checked ~ .panels #one-panel,
#two:checked ~ .panels #two-panel,
#three:checked ~ .panels #three-panel,
#four:checked ~ .panels #four-panel {
  display: block;
}

#one:checked ~ .tabs #one-tab,
#two:checked ~ .tabs #two-tab,
#three:checked ~ .tabs #three-tab,
#four:checked ~ .tabs #four-tab {
  color: #5E95B7;
  text-decoration: underline;
}

@media only screen and (min-width: 540px) {
  .tab {
    padding: 10px 15px;
  }
}

/*# sourceMappingURL=style.css.map */

</style>
